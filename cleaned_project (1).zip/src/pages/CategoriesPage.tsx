import React, { useState } from 'react';
import { Plus, Grid3X3, Trash2, Edit3, Save, X, Package } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { Category, Product } from '../types';

export default function CategoriesPage() {
  const [categories, setCategories] = useLocalStorage<Category[]>('warehouse-categories', []);
  const [products] = useLocalStorage<Product[]>('warehouse-products', []);
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingCategory, setEditingCategory] = useState<string | null>(null);
  
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    color: 'bg-blue-500'
  });

  const colorOptions = [
    { value: 'bg-blue-500', label: 'Ko\'k', class: 'bg-blue-500' },
    { value: 'bg-green-500', label: 'Yashil', class: 'bg-green-500' },
    { value: 'bg-purple-500', label: 'Binafsha', class: 'bg-purple-500' },
    { value: 'bg-red-500', label: 'Qizil', class: 'bg-red-500' },
    { value: 'bg-yellow-500', label: 'Sariq', class: 'bg-yellow-500' },
    { value: 'bg-pink-500', label: 'Pushti', class: 'bg-pink-500' },
    { value: 'bg-indigo-500', label: 'Indigo', class: 'bg-indigo-500' },
    { value: 'bg-teal-500', label: 'Teal', class: 'bg-teal-500' }
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim() || !formData.description.trim()) {
      alert('Iltimos, barcha majburiy maydonlarni to\'ldiring');
      return;
    }

    if (editingCategory) {
      setCategories(categories.map(cat => 
        cat.id === editingCategory 
          ? { ...cat, name: formData.name.trim(), description: formData.description.trim(), color: formData.color }
          : cat
      ));
      setEditingCategory(null);
    } else {
      const newCategory: Category = {
        id: Date.now().toString(),
        name: formData.name.trim(),
        description: formData.description.trim(),
        color: formData.color,
        createdAt: new Date().toISOString()
      };
      setCategories([...categories, newCategory]);
    }

    setFormData({
      name: '',
      description: '',
      color: 'bg-blue-500'
    });
    setShowAddForm(false);
  };

  const handleEdit = (category: Category) => {
    setFormData({
      name: category.name,
      description: category.description,
      color: category.color
    });
    setEditingCategory(category.id);
    setShowAddForm(true);
  };

  const handleDelete = (categoryId: string) => {
    const productsInCategory = products.filter(product => product.category === categoryId);
    
    if (productsInCategory.length > 0) {
      alert(`Kategoriyani o'chirib bo'lmaydi. Unda ${productsInCategory.length} ta mahsulot bor. Iltimos, avval mahsulotlarni ko'chiring yoki o'chiring.`);
      return;
    }

    if (window.confirm('Ushbu kategoriyani o\'chirishga ishonchingiz komilmi?')) {
      setCategories(categories.filter(cat => cat.id !== categoryId));
    }
  };

  const cancelEdit = () => {
    setFormData({
      name: '',
      description: '',
      color: 'bg-blue-500'
    });
    setEditingCategory(null);
    setShowAddForm(false);
  };

  const getProductCount = (categoryId: string) => {
    return products.filter(product => product.category === categoryId).length;
  };

  return (
    <div className="space-y-4 sm:space-y-6 pb-20 lg:pb-0">
      {/* Header */}
      <div className="bg-white rounded-xl shadow-lg p-4 sm:p-6 border border-slate-200">
        <div className="flex items-center justify-between">
          <div className="flex-1 min-w-0">
            <h1 className="text-xl sm:text-2xl font-bold text-slate-800 flex items-center gap-2 sm:gap-3">
              <Grid3X3 className="h-6 w-6 sm:h-7 sm:w-7 text-purple-600" />
              <span className="truncate">Kategoriyalar</span>
            </h1>
            <p className="text-slate-600 mt-1 text-sm sm:text-base">Mahsulotlaringizni kategoriyalar bilan tartibga soling</p>
          </div>
          <button
            onClick={() => setShowAddForm(true)}
            className="flex items-center space-x-1 sm:space-x-2 bg-gradient-to-r from-purple-600 to-purple-700 text-white px-3 sm:px-4 py-2 rounded-lg hover:from-purple-700 hover:to-purple-800 focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 transition-all duration-200 shadow-lg hover:shadow-xl flex-shrink-0 ml-2"
          >
            <Plus className="h-4 w-4 sm:h-5 sm:w-5" />
            <span className="hidden sm:inline">Kategoriya Qo'shish</span>
            <span className="sm:hidden">Qo'shish</span>
          </button>
        </div>
      </div>

      {/* Add/Edit Form */}
      {showAddForm && (
        <div className="bg-white rounded-xl shadow-lg border border-slate-200">
          <div className="p-4 sm:p-6">
            <h2 className="text-lg font-semibold text-slate-800 mb-4">
              {editingCategory ? 'Kategoriyani Tahrirlash' : 'Yangi Kategoriya Qo\'shish'}
            </h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-slate-700 mb-2">
                    Kategoriya Nomi *
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    required
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200 text-base"
                    placeholder="Kategoriya nomini kiriting"
                  />
                </div>

                <div>
                  <label htmlFor="color" className="block text-sm font-medium text-slate-700 mb-2">
                    Rang
                  </label>
                  <select
                    id="color"
                    name="color"
                    value={formData.color}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200 bg-white text-base"
                  >
                    {colorOptions.map(option => (
                      <option key={option.value} value={option.value}>
                        {option.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label htmlFor="description" className="block text-sm font-medium text-slate-700 mb-2">
                  Tavsif *
                </label>
                <textarea
                  id="description"
                  name="description"
                  value={formData.description}
                  onChange={handleInputChange}
                  required
                  rows={3}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200 resize-none text-base"
                  placeholder="Kategoriya tavsifini kiriting"
                />
              </div>

              <div className="flex flex-col sm:flex-row justify-end space-y-2 sm:space-y-0 sm:space-x-3 pt-4 border-t border-slate-200">
                <button
                  type="button"
                  onClick={cancelEdit}
                  className="flex items-center justify-center space-x-2 px-4 py-2 text-slate-600 hover:text-slate-800 hover:bg-slate-50 rounded-lg transition-colors duration-200 border border-slate-300"
                >
                  <X className="h-4 w-4" />
                  <span>Bekor Qilish</span>
                </button>
                <button
                  type="submit"
                  className="flex items-center justify-center space-x-2 bg-gradient-to-r from-purple-600 to-purple-700 text-white px-4 py-2 rounded-lg hover:from-purple-700 hover:to-purple-800 focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 transition-all duration-200 shadow-lg hover:shadow-xl"
                >
                  <Save className="h-4 w-4" />
                  <span>{editingCategory ? 'Yangilash' : 'Qo\'shish'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Categories Grid */}
      {categories.length === 0 ? (
        <div className="bg-white rounded-xl shadow-lg p-8 sm:p-12 text-center border border-slate-200">
          <Grid3X3 className="h-12 w-12 sm:h-16 sm:w-16 text-slate-300 mx-auto mb-4" />
          <h3 className="text-lg sm:text-xl font-semibold text-slate-600 mb-2">Hali Kategoriyalar Yo'q</h3>
          <p className="text-slate-500 mb-4 text-sm sm:text-base">Mahsulotlaringizni tartibga solish uchun birinchi kategoriyangizni yarating.</p>
          <button
            onClick={() => setShowAddForm(true)}
            className="inline-flex items-center space-x-2 bg-gradient-to-r from-purple-600 to-purple-700 text-white px-4 py-2 rounded-lg hover:from-purple-700 hover:to-purple-800 transition-all duration-200"
          >
            <Plus className="h-4 w-4" />
            <span>Birinchi Kategoriya Qo'shish</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
          {categories.map(category => (
            <div key={category.id} className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 border border-slate-200 overflow-hidden">
              <div className="p-4 sm:p-6">
                <div className="flex justify-between items-start mb-4">
                  <div className="flex items-center space-x-3 flex-1 min-w-0">
                    <div className={`w-4 h-4 rounded-full ${category.color} flex-shrink-0`}></div>
                    <h3 className="text-base sm:text-lg font-semibold text-slate-800 truncate">{category.name}</h3>
                  </div>
                  <div className="flex space-x-1 flex-shrink-0 ml-2">
                    <button
                      onClick={() => handleEdit(category)}
                      className="p-2 text-blue-500 hover:bg-blue-50 rounded-lg transition-colors duration-200"
                      title="Kategoriyani tahrirlash"
                    >
                      <Edit3 className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => handleDelete(category.id)}
                      className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors duration-200"
                      title="Kategoriyani o'chirish"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>

                <p className="text-slate-600 text-sm mb-4 leading-relaxed line-clamp-3">{category.description}</p>

                <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                  <div className="flex items-center space-x-2">
                    <Package className="h-4 w-4 text-slate-400" />
                    <span className="text-sm text-slate-600">
                      {getProductCount(category.id)} mahsulot
                    </span>
                  </div>
                  <Link
                    to={`/category/${category.id}`}
                    className="text-sm text-purple-600 hover:text-purple-700 font-medium hover:underline transition-colors duration-200 whitespace-nowrap"
                  >
                    Ko'rish →
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}