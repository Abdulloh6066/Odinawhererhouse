import React, { useState } from 'react';
import { Trash2, Search, Package, Filter, Calendar, X, TrendingUp, BarChart3, DollarSign } from 'lucide-react';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { Product, Category } from '../types';

export default function ProductsPage() {
  const [products, setProducts] = useLocalStorage<Product[]>('warehouse-products', []);
  const [categories] = useLocalStorage<Category[]>('warehouse-categories', []);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === '' || product.category === selectedCategory;
    
    // Date filtering
    let matchesDateRange = true;
    if (startDate || endDate) {
      const productDate = new Date(product.dateAdded);
      
      if (startDate) {
        const start = new Date(startDate);
        start.setHours(0, 0, 0, 0);
        if (productDate < start) {
          matchesDateRange = false;
        }
      }
      
      if (endDate) {
        const end = new Date(endDate);
        end.setHours(23, 59, 59, 999);
        if (productDate > end) {
          matchesDateRange = false;
        }
      }
    }
    
    return matchesSearch && matchesCategory && matchesDateRange;
  });

  const handleDeleteProduct = (productId: string) => {
    if (window.confirm('Ushbu mahsulotni o\'chirishga ishonchingiz komilmi?')) {
      setProducts(products.filter(product => product.id !== productId));
    }
  };

  const getCategoryName = (categoryId: string) => {
    const category = categories.find(cat => cat.id === categoryId);
    return category ? category.name : 'Kategoriyasiz';
  };

  const getTotalValue = () => {
    return filteredProducts.reduce((total, product) => total + (product.price * product.quantity), 0);
  };

  const getAllProductsTotalValue = () => {
    return products.reduce((total, product) => total + (product.price * product.quantity), 0);
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('uz-UZ', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(price);
  };

  const formatQuantity = (quantity: number, unit: string) => {
    if (unit === 'kg') {
      return `${quantity} kg`;
    }
    return `${quantity} dona`;
  };

  const formatDateWithUzbekTime = (dateString: string) => {
    const date = new Date(dateString);
    
    return date.toLocaleString('uz-UZ', {
      timeZone: 'Asia/Tashkent',
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: false
    });
  };

  // Quick date filter functions
  const setDateRange = (days: number) => {
    const end = new Date();
    const start = new Date();
    start.setDate(start.getDate() - days);
    
    setStartDate(start.toISOString().split('T')[0]);
    setEndDate(end.toISOString().split('T')[0]);
  };

  const clearDateFilters = () => {
    setStartDate('');
    setEndDate('');
  };

  const setThisMonth = () => {
    const now = new Date();
    const start = new Date(now.getFullYear(), now.getMonth(), 1);
    const end = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    
    setStartDate(start.toISOString().split('T')[0]);
    setEndDate(end.toISOString().split('T')[0]);
  };

  const setLastMonth = () => {
    const now = new Date();
    const start = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    const end = new Date(now.getFullYear(), now.getMonth(), 0);
    
    setStartDate(start.toISOString().split('T')[0]);
    setEndDate(end.toISOString().split('T')[0]);
  };

  return (
    <div className="space-y-6 pb-20 lg:pb-0">
      {/* Beautiful Header with Stats */}
      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl shadow-lg p-6 border border-blue-200">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-3 rounded-xl">
              <Package className="h-7 w-7 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-slate-800">Mahsulotlar Inventari</h1>
              <p className="text-slate-600">Ombor mahsulotlarini boshqaring</p>
            </div>
          </div>
        </div>

        {/* Beautiful Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Total Products */}
          <div className="bg-white rounded-lg p-4 border border-slate-200 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600 mb-1">Jami Mahsulotlar</p>
                <p className="text-2xl font-bold text-blue-600">{products.length}</p>
                <p className="text-xs text-slate-500">Barcha mahsulotlar</p>
              </div>
              <div className="bg-blue-100 p-3 rounded-full">
                <Package className="h-6 w-6 text-blue-600" />
              </div>
            </div>
          </div>

          {/* Filtered Products */}
          <div className="bg-white rounded-lg p-4 border border-slate-200 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600 mb-1">Ko'rsatilgan</p>
                <p className="text-2xl font-bold text-green-600">{filteredProducts.length}</p>
                <p className="text-xs text-slate-500">
                  {filteredProducts.length === products.length 
                    ? 'Barcha mahsulotlar' 
                    : `${products.length} dan filtrlangan`
                  }
                </p>
              </div>
              <div className="bg-green-100 p-3 rounded-full">
                <BarChart3 className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </div>

          {/* Total Value */}
          <div className="bg-white rounded-lg p-4 border border-slate-200 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600 mb-1">Jami Qiymat</p>
                <p className="text-xl font-bold text-orange-600">{formatPrice(getTotalValue())}</p>
                <p className="text-xs text-slate-500">
                  {filteredProducts.length === products.length 
                    ? 'UZS' 
                    : `${formatPrice(getAllProductsTotalValue())} UZS dan`
                  }
                </p>
              </div>
              <div className="bg-orange-100 p-3 rounded-full">
                <DollarSign className="h-6 w-6 text-orange-600" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-lg p-6 border border-slate-200">
        <div className="flex items-center gap-2 mb-4">
          <Filter className="h-5 w-5 text-slate-600" />
          <h2 className="text-lg font-semibold text-slate-800">Filtrlar</h2>
        </div>
        
        <div className="space-y-4">
          {/* Search and Category */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Qidirish</label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Mahsulot nomi yoki tavsifi..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 text-sm"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Kategoriya</label>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 bg-white text-sm"
              >
                <option value="">Barcha Kategoriyalar</option>
                {categories.map(category => (
                  <option key={category.id} value={category.id}>
                    {category.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Date Filters */}
          <div className="border-t border-slate-200 pt-4">
            <div className="flex items-center gap-2 mb-3">
              <Calendar className="h-4 w-4 text-slate-500" />
              <span className="text-sm font-medium text-slate-700">Sana bo'yicha filtr:</span>
              {(startDate || endDate) && (
                <button
                  onClick={clearDateFilters}
                  className="text-xs text-red-600 hover:text-red-800 flex items-center gap-1 ml-auto"
                >
                  <X className="h-3 w-3" />
                  Tozalash
                </button>
              )}
            </div>
            
            {/* Quick Date Buttons */}
            <div className="flex flex-wrap gap-2 mb-4">
              <button
                onClick={() => setDateRange(7)}
                className="px-4 py-2 text-sm bg-blue-50 text-blue-700 border border-blue-200 rounded-lg hover:bg-blue-100 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all duration-200"
              >
                So'nggi 7 kun
              </button>
              <button
                onClick={() => setDateRange(30)}
                className="px-4 py-2 text-sm bg-green-50 text-green-700 border border-green-200 rounded-lg hover:bg-green-100 focus:outline-none focus:ring-2 focus:ring-green-500 transition-all duration-200"
              >
                So'nggi 30 kun
              </button>
              <button
                onClick={setThisMonth}
                className="px-4 py-2 text-sm bg-purple-50 text-purple-700 border border-purple-200 rounded-lg hover:bg-purple-100 focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all duration-200"
              >
                Bu oy
              </button>
              <button
                onClick={setLastMonth}
                className="px-4 py-2 text-sm bg-orange-50 text-orange-700 border border-orange-200 rounded-lg hover:bg-orange-100 focus:outline-none focus:ring-2 focus:ring-orange-500 transition-all duration-200"
              >
                O'tgan oy
              </button>
            </div>

            {/* Custom Date Range */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Boshlanish sanasi</label>
                <input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 text-sm"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Tugash sanasi</label>
                <input
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 text-sm"
                />
              </div>
            </div>

            {/* Date Range Display */}
            {(startDate || endDate) && (
              <div className="mt-3 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                <div className="flex items-center space-x-2">
                  <Calendar className="h-4 w-4 text-blue-600" />
                  <span className="text-sm text-blue-700 font-medium">
                    {startDate && endDate ? (
                      <>Mahsulotlar: {new Date(startDate).toLocaleDateString('uz-UZ')} dan {new Date(endDate).toLocaleDateString('uz-UZ')} gacha</>
                    ) : startDate ? (
                      <>Mahsulotlar: {new Date(startDate).toLocaleDateString('uz-UZ')} dan boshlab</>
                    ) : (
                      <>Mahsulotlar: {new Date(endDate).toLocaleDateString('uz-UZ')} gacha</>
                    )}
                  </span>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Excel-style Table */}
      {filteredProducts.length === 0 ? (
        <div className="bg-white rounded-xl shadow-lg p-8 text-center border border-slate-200">
          <Package className="h-16 w-16 text-slate-300 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-slate-600 mb-2">
            {products.length === 0 
              ? "Mahsulotlar yo'q" 
              : "Filtr bo'yicha mahsulot topilmadi"
            }
          </h3>
          <p className="text-slate-500 mb-4">
            {products.length === 0 
              ? "Birinchi mahsulotingizni qo'shing."
              : "Filtr mezonlarini o'zgartirib ko'ring."
            }
          </p>
          {(startDate || endDate || selectedCategory || searchTerm) && (
            <button
              onClick={() => {
                setSearchTerm('');
                setSelectedCategory('');
                clearDateFilters();
              }}
              className="inline-flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-all duration-200"
            >
              <X className="h-4 w-4" />
              <span>Barcha filtrlarni tozalash</span>
            </button>
          )}
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gradient-to-r from-slate-50 to-slate-100 border-b-2 border-slate-300">
                  <th className="px-4 py-3 text-left font-semibold text-slate-700 border-r border-slate-300">№</th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-700 border-r border-slate-300">Mahsulot Nomi</th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-700 border-r border-slate-300">Tavsif</th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-700 border-r border-slate-300">Kategoriya</th>
                  <th className="px-4 py-3 text-right font-semibold text-slate-700 border-r border-slate-300">Miqdor</th>
                  <th className="px-4 py-3 text-right font-semibold text-slate-700 border-r border-slate-300">Narx (UZS)</th>
                  <th className="px-4 py-3 text-right font-semibold text-slate-700 border-r border-slate-300">Jami (UZS)</th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-700 border-r border-slate-300">Sana</th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-700 border-r border-slate-300">Izoh</th>
                  <th className="px-4 py-3 text-center font-semibold text-slate-700">Amal</th>
                </tr>
              </thead>
              <tbody>
                {filteredProducts.map((product, index) => (
                  <tr key={product.id} className="border-b border-slate-200 hover:bg-slate-50 transition-colors duration-150">
                    <td className="px-4 py-3 border-r border-slate-200 text-slate-600 font-medium">
                      {index + 1}
                    </td>
                    <td className="px-4 py-3 border-r border-slate-200 font-semibold text-slate-800">
                      {product.name}
                    </td>
                    <td className="px-4 py-3 border-r border-slate-200 text-slate-600 max-w-xs">
                      <div className="truncate" title={product.description}>
                        {product.description}
                      </div>
                    </td>
                    <td className="px-4 py-3 border-r border-slate-200 text-slate-600">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                        {getCategoryName(product.category)}
                      </span>
                    </td>
                    <td className="px-4 py-3 border-r border-slate-200 text-right font-semibold text-slate-800">
                      {formatQuantity(product.quantity, product.unit)}
                    </td>
                    <td className="px-4 py-3 border-r border-slate-200 text-right font-semibold text-slate-800">
                      {formatPrice(product.price)}
                    </td>
                    <td className="px-4 py-3 border-r border-slate-200 text-right font-bold text-green-700">
                      {formatPrice(product.price * product.quantity)}
                    </td>
                    <td className="px-4 py-3 border-r border-slate-200 text-slate-600 text-xs">
                      {formatDateWithUzbekTime(product.dateAdded)}
                    </td>
                    <td className="px-4 py-3 border-r border-slate-200 text-slate-600 max-w-xs">
                      <div className="truncate text-xs" title={product.notes || ''}>
                        {product.notes || '-'}
                      </div>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <button
                        onClick={() => handleDeleteProduct(product.id)}
                        className="text-red-600 hover:text-red-800 hover:bg-red-50 p-2 rounded-lg transition-all duration-200"
                        title="O'chirish"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="bg-gradient-to-r from-slate-100 to-slate-200 border-t-2 border-slate-400">
                  <td colSpan="6" className="px-4 py-4 text-right font-bold text-slate-800 border-r border-slate-300 text-base">
                    JAMI QIYMAT:
                  </td>
                  <td className="px-4 py-4 text-right font-bold text-green-700 border-r border-slate-300 text-lg">
                    {formatPrice(getTotalValue())} UZS
                  </td>
                  <td colSpan="3" className="px-4 py-4 text-center text-sm text-slate-600">
                    {filteredProducts.length} mahsulot ko'rsatilgan
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}