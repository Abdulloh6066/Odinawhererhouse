import React, { useState } from 'react';
import { Plus, Package, Save, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { Product, Category } from '../types';

export default function AddProductPage() {
  const navigate = useNavigate();
  const [products, setProducts] = useLocalStorage<Product[]>('warehouse-products', []);
  const [categories] = useLocalStorage<Category[]>('warehouse-categories', []);
  
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    quantity: '',
    unit: 'dona' as 'kg' | 'dona',
    price: '',
    category: '',
    notes: '',
    supplierName: ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim() || !formData.description.trim() || !formData.quantity || !formData.price || !formData.category) {
      alert('Iltimos, barcha majburiy maydonlarni to\'ldiring');
      return;
    }

    // Create date in Uzbekistan timezone (UTC+5)
    const now = new Date();
    const uzbekistanTime = new Date(now.toLocaleString("en-US", {timeZone: "Asia/Tashkent"}));

    const newProduct: Product = {
      id: Date.now().toString(),
      name: formData.name.trim(),
      description: formData.description.trim(),
      quantity: parseFloat(formData.quantity),
      unit: formData.unit,
      price: parseFloat(formData.price),
      category: formData.category,
      dateAdded: uzbekistanTime.toISOString(),
      notes: formData.notes.trim() || undefined,
      isPaidFor: false, // New products start as unpaid debt
      supplierName: formData.supplierName.trim() || undefined
    };

    // Add product to inventory
    setProducts([...products, newProduct]);
    
    setFormData({
      name: '',
      description: '',
      quantity: '',
      unit: 'dona',
      price: '',
      category: '',
      notes: '',
      supplierName: ''
    });

    const totalCost = parseFloat(formData.price) * parseFloat(formData.quantity);
    alert(`Mahsulot muvaffaqiyatli qo'shildi! Qarz miqdori: ${formatPrice(totalCost)}`);
    navigate('/');
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('uz-UZ', {
      style: 'currency',
      currency: 'UZS',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(price);
  };

  const getTotalCost = () => {
    const quantity = parseFloat(formData.quantity) || 0;
    const price = parseFloat(formData.price) || 0;
    return quantity * price;
  };

  return (
    <div className="space-y-4 sm:space-y-6 pb-20 lg:pb-0">
      {/* Header */}
      <div className="bg-white rounded-xl shadow-lg p-4 sm:p-6 border border-slate-200">
        <div className="flex items-center justify-between">
          <div className="flex-1 min-w-0">
            <h1 className="text-xl sm:text-2xl font-bold text-slate-800 flex items-center gap-2 sm:gap-3">
              <Plus className="h-6 w-6 sm:h-7 sm:w-7 text-green-600" />
              <span className="truncate">Yangi Mahsulot Qo'shish</span>
            </h1>
            <p className="text-slate-600 mt-1 text-sm sm:text-base">Ombor inventaringizga yangi mahsulot qo'shing</p>
          </div>
          <button
            onClick={() => navigate('/')}
            className="flex items-center space-x-1 sm:space-x-2 px-3 sm:px-4 py-2 text-slate-600 hover:text-slate-800 hover:bg-slate-50 rounded-lg transition-colors duration-200 flex-shrink-0 ml-2"
          >
            <ArrowLeft className="h-4 w-4" />
            <span className="hidden sm:inline">Mahsulotlarga Qaytish</span>
          </button>
        </div>
      </div>

      {/* Form */}
      <div className="bg-white rounded-xl shadow-lg border border-slate-200">
        <form onSubmit={handleSubmit} className="p-4 sm:p-6 space-y-4 sm:space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
            {/* Product Name */}
            <div className="lg:col-span-2">
              <label htmlFor="name" className="block text-sm font-medium text-slate-700 mb-2">
                Mahsulot Nomi *
              </label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                required
                className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200 text-base"
                placeholder="Mahsulot nomini kiriting"
              />
            </div>

            {/* Quantity and Unit */}
            <div>
              <label htmlFor="quantity" className="block text-sm font-medium text-slate-700 mb-2">
                Miqdori *
              </label>
              <div className="flex space-x-2">
                <input
                  type="number"
                  id="quantity"
                  name="quantity"
                  value={formData.quantity}
                  onChange={handleInputChange}
                  required
                  min="0"
                  step="0.1"
                  className="flex-1 px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200 text-base"
                  placeholder="Miqdorni kiriting"
                />
                <select
                  name="unit"
                  value={formData.unit}
                  onChange={handleInputChange}
                  className="px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200 bg-white text-base min-w-[100px]"
                >
                  <option value="dona">Dona</option>
                  <option value="kg">Kilogram</option>
                </select>
              </div>
            </div>

            {/* Price */}
            <div>
              <label htmlFor="price" className="block text-sm font-medium text-slate-700 mb-2">
                Narxi (UZS) *
              </label>
              <input
                type="number"
                id="price"
                name="price"
                value={formData.price}
                onChange={handleInputChange}
                required
                min="0"
                step="1"
                className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200 text-base"
                placeholder="0"
              />
            </div>

            {/* Category */}
            <div className="lg:col-span-2">
              <label htmlFor="category" className="block text-sm font-medium text-slate-700 mb-2">
                Kategoriya *
              </label>
              <select
                id="category"
                name="category"
                value={formData.category}
                onChange={handleInputChange}
                required
                className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200 bg-white text-base"
              >
                <option value="">Kategoriyani tanlang</option>
                {categories.map(category => (
                  <option key={category.id} value={category.id}>
                    {category.name}
                  </option>
                ))}
              </select>
              {categories.length === 0 && (
                <p className="text-sm text-amber-600 mt-1">
                  Kategoriyalar mavjud emas. Iltimos, avval kategoriya yarating.
                </p>
              )}
            </div>

            {/* Supplier Name */}
            <div className="lg:col-span-2">
              <label htmlFor="supplierName" className="block text-sm font-medium text-slate-700 mb-2">
                Ta'minotchi Nomi (Ixtiyoriy)
              </label>
              <input
                type="text"
                id="supplierName"
                name="supplierName"
                value={formData.supplierName}
                onChange={handleInputChange}
                className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200 text-base"
                placeholder="Kimdan sotib oldingiz?"
              />
            </div>
          </div>

          {/* Description */}
          <div>
            <label htmlFor="description" className="block text-sm font-medium text-slate-700 mb-2">
              Tavsif *
            </label>
            <textarea
              id="description"
              name="description"
              value={formData.description}
              onChange={handleInputChange}
              required
              rows={3}
              className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200 resize-none text-base"
              placeholder="Mahsulot tavsifini kiriting"
            />
          </div>

          {/* Notes */}
          <div>
            <label htmlFor="notes" className="block text-sm font-medium text-slate-700 mb-2">
              Izohlar (Ixtiyoriy)
            </label>
            <textarea
              id="notes"
              name="notes"
              value={formData.notes}
              onChange={handleInputChange}
              rows={2}
              className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200 resize-none text-base"
              placeholder="Qo'shimcha izohlar yoki sharhlar"
            />
          </div>

          {/* Total Cost Display */}
          {formData.quantity && formData.price && (
            <div className="bg-gradient-to-r from-red-50 to-pink-50 rounded-lg p-4 border border-red-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Package className="h-5 w-5 text-red-600" />
                  <span className="text-sm font-medium text-slate-700">Bu mahsulot uchun qarz miqdori:</span>
                </div>
                <span className="text-xl font-bold text-red-600">
                  {formatPrice(getTotalCost())}
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                {formData.quantity} {formData.unit} × {formatPrice(parseFloat(formData.price) || 0)} = {formatPrice(getTotalCost())}
              </p>
            </div>
          )}

          {/* Submit Button */}
          <div className="flex justify-end pt-4 border-t border-slate-200">
            <button
              type="submit"
              disabled={categories.length === 0}
              className={`w-full sm:w-auto flex items-center justify-center space-x-2 px-6 py-3 rounded-lg focus:ring-2 focus:ring-offset-2 transition-all duration-200 shadow-lg hover:shadow-xl text-base font-medium ${
                categories.length === 0
                  ? 'bg-gray-400 text-gray-700 cursor-not-allowed'
                  : 'bg-gradient-to-r from-green-600 to-green-700 text-white hover:from-green-700 hover:to-green-800 focus:ring-green-500'
              }`}
            >
              <Save className="h-5 w-5" />
              <span>Mahsulot Qo'shish</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}