import React, { useState } from 'react';
import { Plus, Minus, Wallet, TrendingUp, TrendingDown, Calendar, FileText, Trash2, Filter, X, Save } from 'lucide-react';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { Category, Product, DebtPayment } from '../types';

interface CashTransaction {
  id: string;
  type: 'income' | 'expense';
  amount: number;
  description: string;
  category: string;
  date: string;
  notes?: string;
  supplierName?: string; // Add supplier name for expenses
}

export default function CashFlowPage() {
  const [transactions, setTransactions] = useLocalStorage<CashTransaction[]>('cash-transactions', []);
  const [categories] = useLocalStorage<Category[]>('warehouse-categories', []);
  const [products, setProducts] = useLocalStorage<Product[]>('warehouse-products', []);
  const [debtPayments, setDebtPayments] = useLocalStorage<DebtPayment[]>('debt-payments', []);
  const [showAddForm, setShowAddForm] = useState(false);
  const [formType, setFormType] = useState<'income' | 'expense'>('income');
  const [filterType, setFilterType] = useState<'all' | 'income' | 'expense'>('all');
  const [filterCategory, setFilterCategory] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  
  const [formData, setFormData] = useState({
    amount: '',
    description: '',
    category: '',
    notes: '',
    supplierName: '' // Add supplier name field
  });

  // Get unique supplier names from products
  const getUniqueSuppliers = () => {
    const suppliers = new Set(
      products
        .filter(p => p.supplierName && p.supplierName.trim())
        .map(p => p.supplierName!.trim())
    );
    return Array.from(suppliers).sort();
  };

  // Calculate debt for a product
  const getProductDebt = (product: Product) => {
    const totalCost = product.price * product.quantity;
    const totalPaid = debtPayments
      .filter(payment => payment.productId === product.id)
      .reduce((sum, payment) => sum + payment.amount, 0);
    return Math.max(0, totalCost - totalPaid);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleShowForm = (type: 'income' | 'expense') => {
    setFormType(type);
    setFormData({
      amount: '',
      description: '',
      category: '',
      notes: '',
      supplierName: ''
    });
    setShowAddForm(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.amount || !formData.description.trim() || !formData.category) {
      alert('Iltimos, barcha majburiy maydonlarni to\'ldiring');
      return;
    }

    const now = new Date();
    const uzbekTime = new Date(now.toLocaleString("en-US", {timeZone: "Asia/Tashkent"}));

    const newTransaction: CashTransaction = {
      id: Date.now().toString(),
      type: formType,
      amount: parseFloat(formData.amount),
      description: formData.description.trim(),
      category: formData.category,
      date: uzbekTime.toISOString(),
      notes: formData.notes.trim() || undefined,
      supplierName: formData.supplierName.trim() || undefined
    };

    // If it's an expense with a supplier name, deduct from supplier's debt
    if (formType === 'expense' && formData.supplierName.trim()) {
      const supplierName = formData.supplierName.trim();
      const expenseAmount = parseFloat(formData.amount);
      
      console.log('Processing expense deduction for:', supplierName, 'Amount:', expenseAmount);

      // Find the selected category name
      const selectedCategory = categories.find(cat => cat.id === formData.category);
      const categoryName = selectedCategory ? selectedCategory.name : '';

      // Find products that match either:
      // 1. Supplier name matches
      // 2. Category name matches the supplier name (for cases like "Goja" category)
      const matchingProducts = products.filter(product => {
        const hasDebt = getProductDebt(product) > 0;
        if (!hasDebt) return false;

        // Check supplier name match
        if (product.supplierName) {
          const productSupplier = product.supplierName.toLowerCase().trim();
          const searchSupplier = supplierName.toLowerCase().trim();
          
          if (productSupplier.includes(searchSupplier) || searchSupplier.includes(productSupplier)) {
            return true;
          }
        }

        // Check if the selected category name matches the supplier name
        // This handles cases where user selects "Goja" category for "Goja" supplier
        if (categoryName) {
          const categoryNameLower = categoryName.toLowerCase().trim();
          const supplierNameLower = supplierName.toLowerCase().trim();
          
          if (categoryNameLower.includes(supplierNameLower) || supplierNameLower.includes(categoryNameLower)) {
            // Also check if this product belongs to this category
            if (product.category === formData.category) {
              return true;
            }
          }
        }

        return false;
      });

      console.log('Found matching products with debt:', matchingProducts.length);

      if (matchingProducts.length > 0) {
        // Sort by debt amount (highest first)
        matchingProducts.sort((a, b) => getProductDebt(b) - getProductDebt(a));

        let remainingDeduction = expenseAmount;
        const deductionsToMake: { productId: string; amount: number; productName: string }[] = [];

        // Distribute deduction across products
        for (const product of matchingProducts) {
          if (remainingDeduction <= 0) break;
          
          const productDebt = getProductDebt(product);
          const deductionForThisProduct = Math.min(remainingDeduction, productDebt);
          
          deductionsToMake.push({
            productId: product.id,
            amount: deductionForThisProduct,
            productName: product.name
          });
          
          remainingDeduction -= deductionForThisProduct;
        }

        if (deductionsToMake.length > 0) {
          // Create payment records (deductions are recorded as payments)
          const newPayments: DebtPayment[] = deductionsToMake.map((deduction, index) => ({
            id: (Date.now() + index + 1000).toString(), // Ensure unique IDs
            productId: deduction.productId,
            amount: deduction.amount,
            paymentDate: uzbekTime.toISOString(),
            notes: `${formData.description} harajati - ${supplierName} dan ${formatPrice(expenseAmount)} chegirma (${deduction.productName})`
          }));

          setDebtPayments([...newPayments, ...debtPayments]);

          const totalDeducted = deductionsToMake.reduce((sum, d) => sum + d.amount, 0);
          
          console.log('Deductions made:', deductionsToMake);
          console.log('Total deducted:', totalDeducted);
          
          // Show success message
          let deductionMessage = `\n\n✅ Qarz Chegirmasi: ${formatPrice(totalDeducted)} ${supplierName} dan chegirma qilindi`;
          if (remainingDeduction > 0) {
            deductionMessage += `\n⚠️ ${formatPrice(remainingDeduction)} ortiqcha (barcha qarzlar to'langan)`;
          }
          
          // Update the transaction notes to include deduction info
          newTransaction.notes = (newTransaction.notes || '') + deductionMessage;
        }
      } else {
        // If no direct matches found, show helpful message
        const availableSuppliers = getUniqueSuppliers();
        const availableCategories = categories.map(cat => cat.name);
        
        console.log('No matching products found for:', supplierName);
        console.log('Available suppliers:', availableSuppliers);
        console.log('Available categories:', availableCategories);
        
        // Still add the transaction but without debt deduction
        newTransaction.notes = (newTransaction.notes || '') + `\n\n⚠️ "${supplierName}" uchun qarzda mahsulot topilmadi`;
      }
    }

    setTransactions([newTransaction, ...transactions]);
    
    setFormData({
      amount: '',
      description: '',
      category: '',
      notes: '',
      supplierName: ''
    });
    setShowAddForm(false);
    
    const message = formType === 'income' 
      ? 'Daromad muvaffaqiyatli qo\'shildi!'
      : formData.supplierName.trim() 
        ? `Harajat qo'shildi va ${formData.supplierName} dan qarz chegirma qilindi!`
        : 'Harajat muvaffaqiyatli qo\'shildi!';
    
    alert(message);
  };

  const handleDelete = (transactionId: string) => {
    if (window.confirm('Ushbu tranzaksiyani o\'chirishga ishonchingiz komilmi?')) {
      setTransactions(transactions.filter(t => t.id !== transactionId));
    }
  };

  const cancelForm = () => {
    setFormData({
      amount: '',
      description: '',
      category: '',
      notes: '',
      supplierName: ''
    });
    setShowAddForm(false);
  };

  const filteredTransactions = transactions.filter(transaction => {
    const matchesType = filterType === 'all' || transaction.type === filterType;
    const matchesCategory = filterCategory === '' || transaction.category === filterCategory;
    
    let matchesDateRange = true;
    if (startDate || endDate) {
      const transactionDate = new Date(transaction.date);
      
      if (startDate) {
        const start = new Date(startDate);
        start.setHours(0, 0, 0, 0);
        if (transactionDate < start) {
          matchesDateRange = false;
        }
      }
      
      if (endDate) {
        const end = new Date(endDate);
        end.setHours(23, 59, 59, 999);
        if (transactionDate > end) {
          matchesDateRange = false;
        }
      }
    }
    
    return matchesType && matchesCategory && matchesDateRange;
  });

  const getTotalIncome = () => {
    return filteredTransactions
      .filter(t => t.type === 'income')
      .reduce((total, t) => total + t.amount, 0);
  };

  const getTotalExpense = () => {
    return filteredTransactions
      .filter(t => t.type === 'expense')
      .reduce((total, t) => total + t.amount, 0);
  };

  const getBalance = () => {
    return getTotalIncome() - getTotalExpense();
  };

  const getCategoryName = (categoryId: string) => {
    const category = categories.find(cat => cat.id === categoryId);
    return category ? category.name : 'Kategoriyasiz';
  };

  const getCategoryColor = (categoryId: string) => {
    const category = categories.find(cat => cat.id === categoryId);
    return category ? category.color : 'bg-gray-500';
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('uz-UZ', {
      style: 'currency',
      currency: 'UZS',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(price);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString('uz-UZ', {
      timeZone: 'Asia/Tashkent',
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const clearFilters = () => {
    setStartDate('');
    setEndDate('');
    setFilterCategory('');
  };

  return (
    <div className="space-y-4 sm:space-y-6 pb-20 lg:pb-0">
      {/* Header */}
      <div className="bg-white rounded-xl shadow-lg p-4 sm:p-6 border border-slate-200">
        <div className="flex items-center justify-between">
          <div className="flex-1 min-w-0">
            <h1 className="text-xl sm:text-2xl font-bold text-slate-800 flex items-center gap-2 sm:gap-3">
              <Wallet className="h-6 w-6 sm:h-7 sm:w-7 text-orange-600" />
              <span className="truncate">Kassa Boshqaruvi</span>
            </h1>
            <p className="text-slate-600 mt-1 text-sm sm:text-base">Pul oqimini kuzatib boring</p>
          </div>
          
          {/* Action Buttons */}
          <div className="flex space-x-2 flex-shrink-0 ml-2">
            <button
              onClick={() => handleShowForm('income')}
              className="flex items-center space-x-1 sm:space-x-2 bg-gradient-to-r from-green-600 to-green-700 text-white px-3 sm:px-4 py-2 rounded-lg hover:from-green-700 hover:to-green-800 focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-all duration-200 shadow-lg hover:shadow-xl"
            >
              <Plus className="h-4 w-4 sm:h-5 sm:w-5" />
              <span className="hidden sm:inline">Daromad+</span>
              <span className="sm:hidden">+</span>
            </button>
            <button
              onClick={() => handleShowForm('expense')}
              className="flex items-center space-x-1 sm:space-x-2 bg-gradient-to-r from-red-600 to-red-700 text-white px-3 sm:px-4 py-2 rounded-lg hover:from-red-700 hover:to-red-800 focus:ring-2 focus:ring-red-500 focus:ring-offset-2 transition-all duration-200 shadow-lg hover:shadow-xl"
            >
              <Minus className="h-4 w-4 sm:h-5 sm:w-5" />
              <span className="hidden sm:inline">Harajat-</span>
              <span className="sm:hidden">-</span>
            </button>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white rounded-xl shadow-lg p-4 sm:p-6 border border-slate-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-slate-600">Jami Daromad</p>
              <p className="text-xl sm:text-2xl font-bold text-green-600">{formatPrice(getTotalIncome())}</p>
            </div>
            <div className="bg-green-100 p-3 rounded-full">
              <TrendingUp className="h-6 w-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-4 sm:p-6 border border-slate-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-slate-600">Jami Xarajat</p>
              <p className="text-xl sm:text-2xl font-bold text-red-600">{formatPrice(getTotalExpense())}</p>
            </div>
            <div className="bg-red-100 p-3 rounded-full">
              <TrendingDown className="h-6 w-6 text-red-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-4 sm:p-6 border border-slate-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-slate-600">Balans</p>
              <p className={`text-xl sm:text-2xl font-bold ${getBalance() >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {formatPrice(getBalance())}
              </p>
            </div>
            <div className={`p-3 rounded-full ${getBalance() >= 0 ? 'bg-green-100' : 'bg-red-100'}`}>
              <Wallet className={`h-6 w-6 ${getBalance() >= 0 ? 'text-green-600' : 'text-red-600'}`} />
            </div>
          </div>
        </div>
      </div>

      {/* Add Transaction Form */}
      {showAddForm && (
        <div className="bg-white rounded-xl shadow-lg border border-slate-200">
          <div className="p-4 sm:p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-slate-800 flex items-center gap-2">
                {formType === 'income' ? (
                  <>
                    <div className="bg-green-100 p-2 rounded-full">
                      <Plus className="h-5 w-5 text-green-600" />
                    </div>
                    Daromad+ Qo'shish
                  </>
                ) : (
                  <>
                    <div className="bg-red-100 p-2 rounded-full">
                      <Minus className="h-5 w-5 text-red-600" />
                    </div>
                    Harajat- Qo'shish
                  </>
                )}
              </h2>
              <button
                onClick={cancelForm}
                className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-50 rounded-lg transition-colors duration-200"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Miqdor (UZS) *
                  </label>
                  <input
                    type="number"
                    name="amount"
                    value={formData.amount}
                    onChange={handleInputChange}
                    required
                    min="0"
                    step="1"
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200 text-base"
                    placeholder="0"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Kategoriya *
                  </label>
                  <select
                    name="category"
                    value={formData.category}
                    onChange={handleInputChange}
                    required
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200 bg-white text-base"
                  >
                    <option value="">Kategoriyani tanlang</option>
                    {categories.map(category => (
                      <option key={category.id} value={category.id}>
                        {category.name}
                      </option>
                    ))}
                  </select>
                  {categories.length === 0 && (
                    <p className="text-sm text-amber-600 mt-1">
                      Kategoriyalar mavjud emas. Iltimos, avval kategoriya yarating.
                    </p>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Tavsif *
                </label>
                <input
                  type="text"
                  name="description"
                  value={formData.description}
                  onChange={handleInputChange}
                  required
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200 text-base"
                  placeholder="Tranzaksiya tavsifi"
                />
              </div>

              {/* Supplier Name Field - Only for Expenses */}
              {formType === 'expense' && (
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Ta'minotchi Nomi (Ixtiyoriy)
                  </label>
                  <input
                    type="text"
                    name="supplierName"
                    value={formData.supplierName}
                    onChange={handleInputChange}
                    list="suppliers"
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all duration-200 text-base"
                    placeholder="Agar ta'minotchi uchun harajat bo'lsa, nomini kiriting"
                  />
                  <datalist id="suppliers">
                    {getUniqueSuppliers().map(supplier => (
                      <option key={supplier} value={supplier} />
                    ))}
                    {/* Also add category names as suggestions */}
                    {categories.map(category => (
                      <option key={`cat-${category.id}`} value={category.name} />
                    ))}
                  </datalist>
                  <div className="mt-2 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                    <p className="text-xs text-blue-700">
                      💡 <strong>Maslahat:</strong> Agar bu harajat ta'minotchi uchun bo'lsa (masalan: Go'ja uchun benzin, Mahmud O'ga uchun transport), 
                      ta'minotchi nomini kiriting. Bu harajat avtomatik ravishda uning qarzidan chegirma qilinadi.
                    </p>
                    <p className="text-xs text-blue-600 mt-1">
                      <strong>Muhim:</strong> Agar siz kategoriya nomini (masalan "Goja") ta'minotchi nomi sifatida kiritasiz, 
                      sistema o'sha kategoriyaga tegishli barcha qarzli mahsulotlardan chegirma qiladi.
                    </p>
                    {getUniqueSuppliers().length > 0 && (
                      <div className="mt-2">
                        <p className="text-xs font-medium text-blue-800 mb-1">Mavjud ta'minotchilar:</p>
                        <div className="flex flex-wrap gap-1">
                          {getUniqueSuppliers().map(supplier => (
                            <button
                              key={supplier}
                              type="button"
                              onClick={() => setFormData(prev => ({ ...prev, supplierName: supplier }))}
                              className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded hover:bg-blue-200 transition-colors duration-200"
                            >
                              {supplier}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                    {categories.length > 0 && (
                      <div className="mt-2">
                        <p className="text-xs font-medium text-purple-800 mb-1">Kategoriya nomlari:</p>
                        <div className="flex flex-wrap gap-1">
                          {categories.map(category => (
                            <button
                              key={category.id}
                              type="button"
                              onClick={() => setFormData(prev => ({ ...prev, supplierName: category.name }))}
                              className="text-xs bg-purple-100 text-purple-700 px-2 py-1 rounded hover:bg-purple-200 transition-colors duration-200"
                            >
                              {category.name}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Izohlar (Ixtiyoriy)
                </label>
                <textarea
                  name="notes"
                  value={formData.notes}
                  onChange={handleInputChange}
                  rows={2}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200 resize-none text-base"
                  placeholder="Qo'shimcha izohlar"
                />
              </div>

              <div className="flex flex-col sm:flex-row justify-end space-y-2 sm:space-y-0 sm:space-x-3 pt-4 border-t border-slate-200">
                <button
                  type="button"
                  onClick={cancelForm}
                  className="flex items-center justify-center space-x-2 px-4 py-2 text-slate-600 hover:text-slate-800 hover:bg-slate-50 rounded-lg transition-colors duration-200 border border-slate-300"
                >
                  <X className="h-4 w-4" />
                  <span>Bekor Qilish</span>
                </button>
                <button
                  type="submit"
                  disabled={categories.length === 0}
                  className={`flex items-center justify-center space-x-2 text-white px-4 py-2 rounded-lg focus:ring-2 focus:ring-offset-2 transition-all duration-200 shadow-lg hover:shadow-xl ${
                    categories.length === 0
                      ? 'bg-gray-400 cursor-not-allowed'
                      : formType === 'income' 
                        ? 'bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 focus:ring-green-500'
                        : 'bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 focus:ring-red-500'
                  }`}
                >
                  <Save className="h-4 w-4" />
                  <span>
                    {formType === 'income' ? 'Daromad+ Qo\'shish' : 'Harajat- Qo\'shish'}
                    {formType === 'expense' && formData.supplierName.trim() && ' + Qarz Chegirma'}
                  </span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-lg p-4 sm:p-6 border border-slate-200">
        <div className="flex items-center gap-2 mb-4">
          <Filter className="h-5 w-5 text-slate-600" />
          <h2 className="text-lg font-semibold text-slate-800">Filtrlar</h2>
          {(startDate || endDate || filterCategory) && (
            <button
              onClick={clearFilters}
              className="ml-auto text-sm text-orange-600 hover:text-orange-700 font-medium"
            >
              Barcha Filtrlarni Tozalash
            </button>
          )}
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Turi
            </label>
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value as 'all' | 'income' | 'expense')}
              className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all duration-200 bg-white text-base"
            >
              <option value="all">Barchasi</option>
              <option value="income">Daromad+</option>
              <option value="expense">Harajat-</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Kategoriya
            </label>
            <select
              value={filterCategory}
              onChange={(e) => setFilterCategory(e.target.value)}
              className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all duration-200 bg-white text-base"
            >
              <option value="">Barcha Kategoriyalar</option>
              {categories.map(category => (
                <option key={category.id} value={category.id}>
                  {category.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Boshlanish sanasi
            </label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all duration-200 text-base"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Tugash sanasi
            </label>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all duration-200 text-base"
            />
          </div>
        </div>
      </div>

      {/* Transactions List */}
      <div className="bg-white rounded-xl shadow-lg border border-slate-200">
        <div className="p-4 sm:p-6">
          <h2 className="text-lg font-semibold text-slate-800 mb-4">
            Tranzaksiyalar ({filteredTransactions.length})
          </h2>
          
          {filteredTransactions.length === 0 ? (
            <div className="text-center py-8">
              <Wallet className="h-12 w-12 text-slate-300 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-slate-600 mb-2">Tranzaksiyalar Yo'q</h3>
              <p className="text-slate-500 text-sm sm:text-base mb-4">
                {transactions.length === 0 
                  ? categories.length === 0
                    ? "Avval kategoriya yarating, keyin tranzaksiya qo'shing."
                    : "Birinchi tranzaksiyangizni qo'shishdan boshlang."
                  : "Filtr mezonlarini o'zgartirib ko'ring."
                }
              </p>
              {transactions.length === 0 && categories.length > 0 && (
                <div className="flex flex-col sm:flex-row items-center justify-center space-y-2 sm:space-y-0 sm:space-x-4">
                  <button
                    onClick={() => handleShowForm('income')}
                    className="flex items-center space-x-2 bg-gradient-to-r from-green-600 to-green-700 text-white px-4 py-2 rounded-lg hover:from-green-700 hover:to-green-800 transition-all duration-200"
                  >
                    <Plus className="h-4 w-4" />
                    <span>Daromad+ Qo'shish</span>
                  </button>
                  <button
                    onClick={() => handleShowForm('expense')}
                    className="flex items-center space-x-2 bg-gradient-to-r from-red-600 to-red-700 text-white px-4 py-2 rounded-lg hover:from-red-700 hover:to-red-800 transition-all duration-200"
                  >
                    <Minus className="h-4 w-4" />
                    <span>Harajat- Qo'shish</span>
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-3">
              {filteredTransactions.map(transaction => (
                <div key={transaction.id} className="border border-slate-200 rounded-lg p-4 hover:shadow-md transition-shadow duration-200">
                  <div className="flex items-start justify-between">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-3 mb-2">
                        <div className={`p-2 rounded-full ${transaction.type === 'income' ? 'bg-green-100' : 'bg-red-100'}`}>
                          {transaction.type === 'income' ? (
                            <TrendingUp className="h-4 w-4 text-green-600" />
                          ) : (
                            <TrendingDown className="h-4 w-4 text-red-600" />
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <h3 className="font-medium text-slate-800 truncate">{transaction.description}</h3>
                          <div className="flex items-center space-x-2 mt-1">
                            <div className={`w-3 h-3 rounded-full ${getCategoryColor(transaction.category)} flex-shrink-0`}></div>
                            <span className="text-sm text-slate-600 truncate">{getCategoryName(transaction.category)}</span>
                            {transaction.supplierName && (
                              <>
                                <span className="text-slate-400">•</span>
                                <span className="text-sm text-blue-600 truncate">{transaction.supplierName}</span>
                              </>
                            )}
                          </div>
                        </div>
                        <div className="text-right flex-shrink-0">
                          <p className={`text-lg font-bold ${transaction.type === 'income' ? 'text-green-600' : 'text-red-600'}`}>
                            {transaction.type === 'income' ? '+' : '-'}{formatPrice(transaction.amount)}
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4 text-sm text-slate-500">
                          <div className="flex items-center space-x-1">
                            <Calendar className="h-4 w-4" />
                            <span>{formatDate(transaction.date)}</span>
                          </div>
                          {transaction.notes && (
                            <div className="flex items-center space-x-1">
                              <FileText className="h-4 w-4" />
                              <span className="truncate max-w-[200px]">{transaction.notes}</span>
                            </div>
                          )}
                        </div>
                        <button
                          onClick={() => handleDelete(transaction.id)}
                          className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors duration-200"
                          title="Tranzaksiyani o'chirish"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}