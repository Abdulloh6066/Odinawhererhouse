import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import ProductsPage from './pages/ProductsPage';
import AddProductPage from './pages/AddProductPage';
import CategoriesPage from './pages/CategoriesPage';
import CategoryProductsPage from './pages/CategoryProductsPage';
import CashFlowPage from './pages/CashFlowPage';
import DebtPage from './pages/DebtPage';

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<ProductsPage />} />
          <Route path="/add-product" element={<AddProductPage />} />
          <Route path="/categories" element={<CategoriesPage />} />
          <Route path="/category/:categoryId" element={<CategoryProductsPage />} />
          <Route path="/cash-flow" element={<CashFlowPage />} />
          <Route path="/debt" element={<DebtPage />} />
        </Routes>
      </Layout>
    </Router>
  );
}

export default App;