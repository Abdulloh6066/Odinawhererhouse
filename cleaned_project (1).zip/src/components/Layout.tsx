import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Package, Plus, Grid3X3, Wallet, Menu, X, CreditCard, Shield } from 'lucide-react';
import BackupManager from './BackupManager';
import { useBackup } from '../hooks/useBackup';

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [showBackupManager, setShowBackupManager] = useState(false);
  const { createAutoBackup, getBackupStats } = useBackup();

  const navItems = [
    { path: '/', icon: Package, label: 'Mahsulotlar', color: 'text-blue-600' },
    { path: '/add-product', icon: Plus, label: 'Mahsulot Qo\'shish', color: 'text-green-600' },
    { path: '/categories', icon: Grid3X3, label: 'Kategoriyalar', color: 'text-purple-600' },
    { path: '/cash-flow', icon: Wallet, label: 'Kassa', color: 'text-orange-600' },
    { path: '/debt', icon: CreditCard, label: 'Qarzlar', color: 'text-red-600' },
  ];

  // Auto backup every 30 minutes
  useEffect(() => {
    const stats = getBackupStats();
    const now = new Date();
    const lastBackup = stats.lastAutoBackup;
    
    // Create initial backup if none exists
    if (!lastBackup) {
      createAutoBackup();
    } else {
      // Check if 30 minutes have passed since last backup
      const timeDiff = now.getTime() - lastBackup.getTime();
      const thirtyMinutes = 30 * 60 * 1000;
      
      if (timeDiff > thirtyMinutes) {
        createAutoBackup();
      }
    }

    // Set up interval for auto backup every 30 minutes
    const interval = setInterval(() => {
      createAutoBackup();
    }, 30 * 60 * 1000); // 30 minutes

    return () => clearInterval(interval);
  }, [createAutoBackup, getBackupStats]);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Mobile Header */}
      <header className="bg-white shadow-lg border-b border-slate-200 sticky top-0 z-50">
        <div className="px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-14 sm:h-16">
            <div className="flex items-center space-x-2 sm:space-x-3">
              <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-1.5 sm:p-2 rounded-lg">
                <Package className="h-5 w-5 sm:h-6 sm:w-6 text-white" />
              </div>
              <h1 className="text-lg sm:text-xl font-bold text-slate-800">Ombor Boshqaruvchisi</h1>
            </div>
            
            <div className="flex items-center space-x-2">
              {/* Backup Button */}
              <button
                onClick={() => setShowBackupManager(true)}
                className="p-2 text-slate-600 hover:text-slate-800 hover:bg-slate-50 rounded-lg transition-colors duration-200"
                title="Ma'lumotlar Backup"
              >
                <Shield className="h-5 w-5" />
              </button>
              
              {/* Mobile Menu Button */}
              <button
                onClick={toggleMobileMenu}
                className="lg:hidden p-2 text-slate-600 hover:text-slate-800 hover:bg-slate-50 rounded-lg transition-colors duration-200"
              >
                {isMobileMenuOpen ? (
                  <X className="h-6 w-6" />
                ) : (
                  <Menu className="h-6 w-6" />
                )}
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Desktop Sidebar */}
        <nav className="hidden lg:block w-64 bg-white shadow-lg min-h-screen border-r border-slate-200">
          <div className="p-6">
            {/* Backup Button in Sidebar */}
            <div className="mb-6">
              <button
                onClick={() => setShowBackupManager(true)}
                className="w-full flex items-center space-x-3 px-4 py-3 rounded-lg bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-200 hover:from-blue-100 hover:to-purple-100 transition-all duration-200"
              >
                <Shield className="h-5 w-5 text-blue-600" />
                <span className="font-medium text-slate-800">Ma'lumotlar Backup</span>
              </button>
            </div>
            
            <ul className="space-y-2">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = location.pathname === item.path;
                
                return (
                  <li key={item.path}>
                    <Link
                      to={item.path}
                      className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 ${
                        isActive
                          ? 'bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-200 shadow-sm'
                          : 'hover:bg-slate-50 hover:shadow-sm'
                      }`}
                    >
                      <Icon className={`h-5 w-5 ${isActive ? item.color : 'text-slate-500'}`} />
                      <span className={`font-medium ${isActive ? 'text-slate-800' : 'text-slate-600'}`}>
                        {item.label}
                      </span>
                    </Link>
                  </li>
                );
              })}
            </ul>
          </div>
        </nav>

        {/* Mobile Navigation Overlay */}
        {isMobileMenuOpen && (
          <div className="lg:hidden fixed inset-0 z-40 bg-black bg-opacity-50" onClick={closeMobileMenu}>
            <div className="fixed inset-y-0 left-0 w-64 bg-white shadow-xl" onClick={(e) => e.stopPropagation()}>
              <div className="p-6 pt-20">
                {/* Mobile Backup Button */}
                <div className="mb-6">
                  <button
                    onClick={() => {
                      setShowBackupManager(true);
                      closeMobileMenu();
                    }}
                    className="w-full flex items-center space-x-3 px-4 py-4 rounded-lg bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-200 hover:from-blue-100 hover:to-purple-100 transition-all duration-200"
                  >
                    <Shield className="h-6 w-6 text-blue-600" />
                    <span className="font-medium text-lg text-slate-800">Ma'lumotlar Backup</span>
                  </button>
                </div>
                
                <ul className="space-y-2">
                  {navItems.map((item) => {
                    const Icon = item.icon;
                    const isActive = location.pathname === item.path;
                    
                    return (
                      <li key={item.path}>
                        <Link
                          to={item.path}
                          onClick={closeMobileMenu}
                          className={`flex items-center space-x-3 px-4 py-4 rounded-lg transition-all duration-200 ${
                            isActive
                              ? 'bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-200 shadow-sm'
                              : 'hover:bg-slate-50 hover:shadow-sm'
                          }`}
                        >
                          <Icon className={`h-6 w-6 ${isActive ? item.color : 'text-slate-500'}`} />
                          <span className={`font-medium text-lg ${isActive ? 'text-slate-800' : 'text-slate-600'}`}>
                            {item.label}
                          </span>
                        </Link>
                      </li>
                    );
                  })}
                </ul>
              </div>
            </div>
          </div>
        )}

        {/* Main Content */}
        <main className="flex-1 p-3 sm:p-4 lg:p-8">
          <div className="max-w-6xl mx-auto">
            {children}
          </div>
        </main>
      </div>

      {/* Mobile Bottom Navigation */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 shadow-lg z-30">
        <div className="grid grid-cols-5 h-16">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex flex-col items-center justify-center space-y-1 transition-all duration-200 ${
                  isActive ? 'bg-gradient-to-t from-blue-50 to-transparent' : 'hover:bg-slate-50'
                }`}
              >
                <Icon className={`h-5 w-5 ${isActive ? item.color : 'text-slate-500'}`} />
                <span className={`text-xs font-medium ${isActive ? 'text-slate-800' : 'text-slate-600'}`}>
                  {item.label.split(' ')[0]}
                </span>
              </Link>
            );
          })}
        </div>
      </nav>

      {/* Mobile Bottom Padding */}
      <div className="lg:hidden h-16"></div>

      {/* Backup Manager Modal */}
      <BackupManager 
        isOpen={showBackupManager} 
        onClose={() => setShowBackupManager(false)} 
      />
    </div>
  );
}